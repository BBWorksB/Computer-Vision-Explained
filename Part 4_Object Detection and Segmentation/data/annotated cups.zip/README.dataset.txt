# annotated cups > 2025-03-16 6:08pm
https://universe.roboflow.com/the-alchemists-workshop/annotated-cups

Provided by a Roboflow user
License: CC BY 4.0

